<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" text="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" text="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" text="text/css" href="fonts/flaticon.css"/>
<link rel="stylesheet" text="text/css" href="fonts/fonts2/flaticon.css"/>
</head>
<body>

<form method="POST" enctype="multipart/form-data">
  <input type="text" name="State" placeholder="State"/><br /><br />

  <input type="submit" name="submit"/><br /><br />
</form>

</body>
</html>
<?php
$connection=mysqli_connect("localhost","root","","state");
if (!$connection){
    die ("error".mysqli_connect_error());
} else{
    "";
}
if (isset($_POST['submit'])){
    $state=$_POST['State'];
   
    $insert="INSERT INTO asiastate (China_state) VALUES ('$state')";
    $result=mysqli_query($connection,$insert);
    if (!$result){
        die ("error".mysqli_connect_error());
    }else{
          echo "<script> alert('All Succesfully entered Database') </script>";
            //$_SESSION['email']=$email;
    }
}
?>
