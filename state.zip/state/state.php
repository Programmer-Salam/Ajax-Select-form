<?php
//session_start();
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" text="text/css" href="bb bbbbbbb/css/bootstrap.min.css"/>
<link rel="stylesheet" text="text/css" href="bb bbbbbbb/css/font-awesome.min.css"/>
<link rel="stylesheet" text="text/css" href="bb bbbbbbb/fonts/flaticon.css"/>
<link rel="stylesheet" text="text/css" href="bb bbbbbbb/fonts/fonts2/flaticon.css"/>
<script type="text/javascript" src="Ajax/js_drop/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    
	$("#amount_cat").change(function() {
		$.get('Ajax/itselect.php?amount_cat=' + $(this).val(), function(data) {
			$("#slot_cat").html(data);
		});	
    });
    
	$("#slot_cat").change(function() {
		$.get('Ajax/itselects.php?slot_cat=' + $(this).val(), function(data) {
			$("#slot_goat").html(data);
		});	
    });
    
	$("#slot_goat").change(function() {
		$.get('Ajax/itselectss.php?slot_goat=' + $(this).val(), function(data) {
			$("#slot_hen").html(data);
		});	
    });



});
</script>
</head>
<body>
  <div class="modal-dialog">
        <div class="modal-content">

            <form action="#" method="POST" enctype="multipart/form-data" >
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
       
         <i class="fa fa-user icon"></i>  <label>First Name</label> <input type="text" name="hr_firstname" class="form-control" placeholder="" required="" autocomplete="off"/>
  <i class="fa fa-user icon"></i> <label>Second Name</label>
<input type="text" name="hr_firstname" class="form-control" placeholder="" required="" autocomplete="off"/>
                               
                            </div>
                        </div>
                    <br />
              
                        </div>
       
                    <div class="row">
        
                        <div class="col-md-12">
                            <div class="form-group">
                        <label for="Corporate">Continent</label>
         
        <select name="amount_cat" id="amount_cat"  class="form-control" required="">
      <option value=""  disabled="disabled"  selected="selected" required>&larr; Select Continent &rarr;</option>
         <option value="Africa" >&rarr; Africa</option>
    <option value="Asia">&rarr; Asia</option>
   <option value="North_America">&rarr; North America</option>
       <option value="South_America">&rarr; South America</option>
                                    <option value="Australia">&rarr; Australia/Ocenia</option>
             <option value="Europe">&rarr; Europe</option>
                                       <option value="Antarctica">&rarr; Antarctica</option>

                 
                        </select>
                        <br />
                                <label>Country</label>
                                  <select name="slot_cat" id="slot_cat" class="form-control" required>
                                   <option>Continent First</option>
                                  <div id="bunks_cat"></div>   
                                </select>
                            </div>
                        </div>
                        </div>
                      
                       <div class="row">
        
                        <div class="col-md-12">
                            <div class="form-group">
                        <label for="Corporate">State</label>
                                <select class="form-control"  name="slot_goat" id="slot_goat">
                                  <option>Country First</option>
                                      <div id="bunks_cat"></div>
                        </select>
                        <br />
                                <label>Local government</label>
                                  <select name="slot_hen" id="slot_hen" class="form-control" required>
                               <option>State First</option>
                                   
                                </select>
                            </div>
                        </div>
                        </div>

<br />
                <div class="modal-footer justify-content-between">
                 
                    <button type="submit" class="btn btn-primary" name="emplo">Save</button>
                </div>
            </form>
        </div>
        
        </body>
</html>
