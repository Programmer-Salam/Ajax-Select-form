<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" text="text/css" href="css/bootstrap.min.css"/>
<link rel="stylesheet" text="text/css" href="css/font-awesome.min.css"/>
<link rel="stylesheet" text="text/css" href="fonts/flaticon.css"/>
<link rel="stylesheet" text="text/css" href="fonts/fonts2/flaticon.css"/>
</head>
<body>

<form method="POST" enctype="multipart/form-data">
  <input type="text" name="AfricaState" placeholder="AfricaState"/><br /><br />
  <input type="text" name="AsiaState" placeholder="AsiaState"/><br /><br />
<input type="text" name="North_AmericaState" placeholder="North_AmericaState"/><br /><br />
<input type="text" name="South_America" placeholder="South_America"/><br /><br />
<input type="text" name="Australia" placeholder="Australia"/><br /><br />
<input type="text" name="Europe" placeholder="Europe"/><br /><br />
<input type="text" name="Antarctica" placeholder="Antarctica"/><br /><br />
  <input type="submit" name="submit"/><br /><br />
</form>

</body>
</html>
<?php
$connection=mysqli_connect("localhost","root","","state");
if (!$connection){
    die ("error".mysqli_connect_error());
} else{
    "";
}
if (isset($_POST['submit'])){
    $firstname=$_POST['AfricaState'];
    $surname=$_POST['AsiaState'];
    $lastname=$_POST['North_AmericaState'];
    $email=$_POST['South_America'];
    $password=$_POST['Australia'];
    $emails=$_POST['Europe'];
    $passwords=$_POST['Antarctica'];
    $insert="INSERT INTO state (AfricaState,AsiaState,North_AmericaState,South_America,Australia,Europe,Antarctica) VALUES ('$firstname','$surname','$lastname','$email','$password','$emails','$passwords')";
    $result=mysqli_query($connection,$insert);
    if (!$result){
        die ("error".mysqli_connect_error());
    }else{
          echo "<script> alert('All Succesfully entered Database') </script>";
            //$_SESSION['email']=$email;
    }
}
?>
