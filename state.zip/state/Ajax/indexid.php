<?php 
if(isset($_GET['session'])&& isset($_GET['class'])){
    $sss= $_GET['session'];
    $classs= $_GET['class'];
}
 
?>

<?php 
include('configuration.php'); 
$query_parent = mysqli_query($conn,"SELECT *  FROM primary1 group by Session order by id asc") or die("Query failed: ".mysqli_error());
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dependent DropDown List</title>
<script type="text/javascript" src="js_drop/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    
	$("#parent_cat").change(function() {
		//$(this).after('<div id="loader"><img src="img_drop/loading.gif" alt="loading subcategory" /></div>');
		$.get('loadsubcat.php?parent_cat=' + $(this).val(), function(data) {
			$("#bunk_cat").html(data);
			//$('#loader').slideUp(200, function() {
			//	$(this).remove();
		//	});
		});	
    });
    //javascript for room
    
    	$("#room_cat").change(function() {
		$(this).after('<div id="loader"><img src="img_drop/loading.gif" alt="loading subcategory" /></div>');
		$.get('second.php?room_cat=' + $(this).val(), function(datas) {
			$("#bunks_cat").html(datas);
			$('#loader').slideUp(200, function() {
				$(this).remove();
			});
		});	
    });

    
    //javascript for room ends herr

});
</script>
</head>

<body>
<form method="get">
	<label for="category">Parent Category</label>
    <select name="parent_cat" id="parent_cat">
    <option>select session*</option>
        <?php while($row = mysqli_fetch_array($query_parent)): ?>
        <option value="<?php echo $row['Session']; ?>"><?php echo $row['Session']; ?></option>
         
        
        <?php endwhile; ?>
    </select>
    <br/><br/>
    
    <div  id="bunk_cat">
   </div>
    <!--select name="room_cat" id="room_cat">
    <option>select session first*</option>
        
    </select-->
    <?php
   if(isset($_GET['session'])&& isset($_GET['class'])){
    $sss= $_GET['session'];
    $classs= $_GET['class'];
    
    $find =mysqli_query($conn,"select * from primary1 where Session='$sss'&& level ='$classs'");
    if(!$find){
        echo "error";
    }
    echo "PAYMENT DETAILS FOR THE YEAR ($sss) CLASS: ($classs)";
    echo "<table>
    <tr><td>s/n</td>
    <td>Names</td>
    <td colspan='4'>Fees</td></tr>";
    while($col=mysqli_fetch_array($find)){
        
        ?>
        <tr>
        <td><?php echo $col['id'];?></td>
        <td><?php echo $col['Student_name'];?></td>
        <td><?php echo $col['firstfee_payment'];?></td>
        
        </tr>
 <?php   }
     
}
    
    ?>
    <br/><br/>
  
   
    <!--label>Bunks Available</label>
    <select name="bunk_cat" id="bunk_cat"><option>select room first*</option></select>
    
    
    
    <!---select roow ends-->
    
    <div class="table-responsive">
                           	<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                                <thead>
                                    <tr>
                                       
                                         <th align="center">S/N</th>
                                        <!--<th>Image</th-->
                                        <th align="center">Name</th>
                                        <th align="center">Gender</th>
                                        <!--<th>Class</th>
                                        <th>Subject</th--->
                                        <th align="center">Amount Paid</th>
                                        <th align="center">Debt</th>
                                        <th align="center">School Fee</th>
                                         <th align="center">Level</th>
                                        <th align="center">confirm</th>
                                        <!--th align="center">E-mail</th-->
                                        <th align="center">Payment Date</th>
                                        <th align="center">Last Checked Date</th>
                                        
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                                                                    <!---<td>
                                           
                                 <div class="form-check">
                                                
                                                <input type="checkbox" class="form-check-input">
                                                
						                  <label class="form-check-label"></label>
                                            </div>
                                                        </td-->           
							
                           <td></td>
                                        <!--<td class="text-center"><img src="img/<?php //echo $row['file']; ?>" style="border:50%" width="5%" alt="student"></td-->
                                        <td></td>
                                        <td></td>
                                        <!--<td>2</td--->
                                        <!---<td>English</td--->
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        
       <td class="badge badge-pill badge-success d-block mg-t-8"><a style='color:white; '>check</a></td>
                                        <!--<td>+ 123 9988568</td-->
                                     
                                        <!--td><//?php echo $row['email']; ?></td-->
                                         <td></td>
                                         <td></td>
                                         <!----<td>
                                            <div class="dropdown">->format('M d,Y h:i:s a')
                                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                                    <span class="flaticon-more-button-of-three-dots"></span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#"><i class="fas fa-times text-orange-red"></i>Close</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-cogs text-dark-pastel-green"></i>Edit</a>
                                                    <a class="dropdown-item" href="#"><i class="fas fa-redo-alt text-orange-peel"></i>Refresh</a>
                                                </div>
                                            </div>
                                        </td---->
                                    </tr>
                                   
                                  
                                </tbody>
                            </table>
                        </div>
    
</form>
</body>
</html>
