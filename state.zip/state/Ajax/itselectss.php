<option value=""  disabled="disabled"  selected="selected" required>&larr; Select Local Government &rarr;</option>
<?php
$parent_cats = $_GET['slot_goat'];

$connection=mysqli_connect("localhost","root","","state");

if (!$connection){ 
    die("error".mysqli_connect_error());
} else {
    echo "";
}
if($parent_cats == 'Lagos'){
$select="SELECT local_lagos FROM local_nigeria";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
//$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $row['local_lagos']; ?>"><?php echo $row['local_lagos']; ?></option>
         
        <?php
    
      }  
}
elseif($parent_cats == 'Ondo'){
$select="SELECT local_ondo FROM local_nigeria";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
//$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $row['local_ondo']; ?>"><?php echo $row['local_ondo']; ?></option>
         
        <?php
    
      }  
}
elseif($parent_cats == 'Osun'){
$select="SELECT local_osun FROM local_nigeria";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
//$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $row['local_osun']; ?>"><?php echo $row['local_osun']; ?></option>
         
        <?php
    
      }  
}elseif($parent_cats == 'Ekiti'){
$select="SELECT local_ekiti FROM local_nigeria";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
//$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $row['local_ekiti']; ?>"><?php echo $row['local_ekiti']; ?></option>
         
        <?php
    
      }  
}
elseif($parent_cats == 'Oyo'){
$select="SELECT local_oyo FROM local_nigeria";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
//$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $row['local_oyo']; ?>"><?php echo $row['local_oyo']; ?></option>
         
        <?php
    
      }  
}


?>
