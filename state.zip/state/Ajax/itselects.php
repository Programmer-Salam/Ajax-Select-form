 <option value=""  disabled="disabled"  selected="selected" required>&larr; Select State &rarr;</option>
<?php
$parent_cat = $_GET['slot_cat'];

$connection=mysqli_connect("localhost","root","","state");

if (!$connection){ 
    die("error".mysqli_connect_error());
} else {
    echo "";
}

if($parent_cat == 'Nigeria'){ 
$select="SELECT Nig_State FROM nigeria";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Nig_State']; ?>"><?php echo $row['Nig_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Chad'){ 
$select="SELECT Chad_State FROM nigeria";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Chad_State']; ?>"><?php echo $row['Chad_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Senegal'){ 
$select="SELECT Senegal_State FROM nigeria";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Senegal_State']; ?>"><?php echo $row['Senegal_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Sudan'){ 
$select="SELECT Sudan_State FROM nigeria";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Sudan_State']; ?>"><?php echo $row['Sudan_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Morocco'){ 
$select="SELECT Morocco_State FROM nigeria";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Morocco_State']; ?>"><?php echo $row['Morocco_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Indonesia'){ 
$selects="SELECT indo_state FROM asiastate";
$results=mysqli_query($connection,$selects);
while($rows = mysqli_fetch_array($results)){
      ?>
        <option value="<?php echo $rows['indo_state']; ?>"><?php echo $rows['indo_state']; ?></option>
        <?php
      }
}elseif($parent_cat == 'China'){ 
$select="SELECT China_state FROM asiastate";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['China_state']; ?>"><?php echo $row['China_state']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Tajikistan'){ 
$select="SELECT Tajikistan_state FROM asiastate";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Tajikistan_state']; ?>"><?php echo $row['Tajikistan_state']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Syria'){ 
$select="SELECT Syria_state FROM asiastate";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Syria_state']; ?>"><?php echo $row['Syria_state']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Jordan'){ 
$select="SELECT Jordan_state FROM asiastate";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Jordan_state']; ?>"><?php echo $row['Jordan_state']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Canada'){ 
$select="SELECT Canada_State FROM north";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Canada_State']; ?>"><?php echo $row['Canada_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Dominica'){ 
$select="SELECT Dominica_State FROM north";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Dominica_State']; ?>"><?php echo $row['Dominica_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Barbados'){ 
$select="SELECT Barbados_State FROM north";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Barbados_State']; ?>"><?php echo $row['Barbados_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Spain'){ 
$select="SELECT Spain_State FROM north";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Spain_State']; ?>"><?php echo $row['Spain_State']; ?></option>
        <?php
      }
}
elseif($parent_cat == 'Costa_Rica'){ 
$select="SELECT Costa_Rica_State FROM north";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Costa_Rica_State']; ?>"><?php echo $row['Costa_Rica_State']; ?></option>
        <?php
      }
}

else{
    echo "<script> alert ('error') </script>";
}
?>