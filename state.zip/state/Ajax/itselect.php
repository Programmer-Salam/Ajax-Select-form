 <option value=""  disabled="disabled"  selected="selected" required>&larr; Select Country &rarr;</option>
<?php
$parent_cat = $_GET['amount_cat'];

$connection=mysqli_connect("localhost","root","","state");

if (!$connection){ 
    die("error".mysqli_connect_error());
} else {
    echo "";
}
if($parent_cat == 'Africa'){
$select="SELECT AfricaState FROM state";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){
$r=$row['AfricaState'];
      ?>
     
        <option value="<?php echo $r; ?>"><?php echo $r; ?></option>
         
        <?php
    
      }  
}

elseif($parent_cat == 'Asia'){
    $select="SELECT AsiaState FROM state";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){

      ?>
        <option value="<?php echo $row['AsiaState']; ?>"><?php echo $row['AsiaState']; ?></option>
         
        <?php
      }
      

}elseif($parent_cat == 'North_America'){
    $select="SELECT North_AmericaState FROM state";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){

      ?>
        <option value="<?php echo $row['North_AmericaState']; ?>"><?php echo $row['North_AmericaState']; ?></option>
         
        <?php
      }
      
  
}
elseif($parent_cat == 'South_America'){
    $select="SELECT South_America FROM state";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['South_America']; ?>"><?php echo $row['South_America']; ?></option>
         
        <?php
      }
}
elseif($parent_cat == 'Australia'){
    $select="SELECT Australia FROM state";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Australia']; ?>"><?php echo $row['Australia']; ?></option>
         
        <?php
      }
}
elseif($parent_cat == 'Europe'){
    $select="SELECT Europe FROM state";
$result=mysqli_query($connection,$select);

while($row = mysqli_fetch_array($result)){

      ?>
        <option value="<?php echo $row['Europe']; ?>"><?php echo $row['Europe']; ?></option>
         
        <?php
      } 
}elseif($parent_cat == 'Antarctica'){
    $select="SELECT Antarctica FROM state";
$result=mysqli_query($connection,$select);
while($row = mysqli_fetch_array($result)){
      ?>
        <option value="<?php echo $row['Antarctica']; ?>"><?php echo $row['Antarctica']; ?></option>
         
        <?php
      }  
}
if($result){
    ;
}else{
    echo "<script> alert('error') </script>";
}

      
      ?>